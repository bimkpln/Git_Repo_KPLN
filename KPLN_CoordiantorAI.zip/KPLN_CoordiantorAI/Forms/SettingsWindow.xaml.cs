﻿using KPLN_CoordiantorAI.Common;
using System;
using System.Windows;

namespace KPLN_CoordiantorAI.Forms
{
    public partial class SettingsWindow : Window
    {
        private readonly CoordinatorAiRepository _repository;

        public SettingsWindow()
        {
            _repository = new CoordinatorAiRepository();
            InitializeComponent();
            LoadSettings();
        }

        private void LoadSettings()
        {
            DbPathTextBox.Text = _repository.DatabaseFilePath;
            LoadGigaChatSettings();
            UpdateDatabaseStatus();
        }

        private void LoadGigaChatSettings()
        {
            GigaChatSettings settings = _repository.DatabaseExists
                ? _repository.LoadGigaChatSettings()
                : new GigaChatSettings();

            AuthUrlTextBox.Text = settings.AuthUrl;
            ApiUrlTextBox.Text = settings.ApiUrl;
            ClientIdTextBox.Text = settings.ClientId;
            ClientSecretPasswordBox.Password = settings.ClientSecret;
            ScopeTextBox.Text = settings.Scope;
        }

        private void OnCreateDatabaseClick(object sender, RoutedEventArgs e)
        {
            try
            {
                _repository.EnsureDatabase();
                LoadGigaChatSettings();
                UpdateDatabaseStatus();
                MessageBox.Show(this, "БД создана или обновлена.", "Координатор ИИ", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.ToString(), "Ошибка создания БД", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OnSaveClick(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!EnsureDatabaseAvailable())
                    return;

                _repository.SaveGigaChatSettings(new GigaChatSettings
                {
                    AuthUrl = AuthUrlTextBox.Text,
                    ApiUrl = ApiUrlTextBox.Text,
                    ClientId = ClientIdTextBox.Text,
                    ClientSecret = ClientSecretPasswordBox.Password,
                    Scope = ScopeTextBox.Text
                });

                UpdateDatabaseStatus();
                MessageBox.Show(this, "Настройки сохранены.", "Координатор ИИ", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.ToString(), "Ошибка сохранения настроек", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OnCloseClick(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private bool EnsureDatabaseAvailable()
        {
            if (_repository.DatabaseExists)
            {
                _repository.EnsureDatabase();
                return true;
            }

            MessageBoxResult result = MessageBox.Show(
                this,
                "БД не найдена. Создать новую?",
                "Координатор ИИ",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes)
                return false;

            _repository.EnsureDatabase();
            return true;
        }

        private void UpdateDatabaseStatus()
        {
            DatabaseStatusTextBlock.Text = _repository.DatabaseExists
                ? "БД найдена: " + _repository.DatabaseFilePath
                : "БД не найдена: " + _repository.DatabaseFilePath;
        }
    }
}
