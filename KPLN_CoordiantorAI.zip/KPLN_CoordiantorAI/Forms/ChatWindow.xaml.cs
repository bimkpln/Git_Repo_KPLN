﻿using KPLN_CoordiantorAI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace KPLN_CoordiantorAI.Forms
{
    public partial class ChatWindow : Window
    {
        private readonly CoordinatorAiRepository _repository;
        private readonly IAiChatClient _aiClient;
        private readonly GigaChatSettings _gigaChatSettings;
        private readonly ChatSession _session;
        private bool _isWaitingForAnswer;

        public ChatWindow(CoordinatorAiRepository repository, IAiChatClient aiClient, CurrentUserContext userContext)
        {
            if (repository == null)
                throw new ArgumentNullException(nameof(repository));
            if (aiClient == null)
                throw new ArgumentNullException(nameof(aiClient));

            _repository = repository;
            _aiClient = aiClient;
            _gigaChatSettings = _repository.LoadGigaChatSettings();
            _session = new ChatSession
            {
                UserName = userContext == null ? Environment.UserName : userContext.UserName,
                SubDepartmentId = userContext == null ? -1 : userContext.SubDepartmentId
            };

            InitializeComponent();
            DataContext = _session;
            SessionInfoTextBlock.Text = string.Format(
                "{0}. Отдел {1}",
                string.IsNullOrWhiteSpace(_session.UserName) ? Environment.UserName : _session.UserName,
                SubDepartmentNameResolver.GetName(_session.SubDepartmentId));

            UpdateReactionButtons();
            SetWaitingState(false);
            SaveSessionSafely();
        }

        private async void OnSendClick(object sender, RoutedEventArgs e)
        {
            await SendCurrentMessageAsync();
        }

        private async void OnMessageTextBoxKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key != Key.Enter || Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
                return;

            e.Handled = true;
            await SendCurrentMessageAsync();
        }

        private async Task SendCurrentMessageAsync()
        {
            if (_isWaitingForAnswer)
                return;

            string messageText = (MessageTextBox.Text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(messageText))
                return;

            ChatMessage userMessage = new ChatMessage
            {
                Role = ChatMessageRole.User,
                Text = messageText
            };

            _session.Messages.Add(userMessage);
            MessageTextBox.Clear();
            ScrollMessagesToEnd();
            SaveSessionSafely();

            SetWaitingState(true);
            try
            {
                List<ChatMessage> requestMessages = _session.Messages.ToList();
                string answer = await _aiClient.SendAsync(requestMessages, _gigaChatSettings, CancellationToken.None);
                _session.Messages.Add(new ChatMessage
                {
                    Role = ChatMessageRole.Assistant,
                    Text = answer
                });
            }
            catch (Exception ex)
            {
                _session.Messages.Add(new ChatMessage
                {
                    Role = ChatMessageRole.Assistant,
                    Text = "Ошибка получения ответа: " + ex.Message
                });
            }
            finally
            {
                SetWaitingState(false);
                ScrollMessagesToEnd();
                SaveSessionSafely();
            }
        }

        private void OnLikeClick(object sender, RoutedEventArgs e)
        {
            SetReaction(_session.Reaction == ChatReaction.Like ? ChatReaction.None : ChatReaction.Like);
        }

        private void OnDislikeClick(object sender, RoutedEventArgs e)
        {
            SetReaction(_session.Reaction == ChatReaction.Dislike ? ChatReaction.None : ChatReaction.Dislike);
        }

        private void SetReaction(ChatReaction reaction)
        {
            _session.Reaction = reaction;
            UpdateReactionButtons();
            SaveSessionSafely();
        }

        private void UpdateReactionButtons()
        {
            Brush defaultBackground = new SolidColorBrush(Color.FromRgb(47, 53, 66));
            Brush activeBackground = new SolidColorBrush(Color.FromRgb(44, 107, 237));
            Brush dislikeBackground = new SolidColorBrush(Color.FromRgb(176, 70, 70));

            LikeButton.Background = _session.Reaction == ChatReaction.Like ? activeBackground : defaultBackground;
            DislikeButton.Background = _session.Reaction == ChatReaction.Dislike ? dislikeBackground : defaultBackground;
        }

        private void SetWaitingState(bool isWaiting)
        {
            _isWaitingForAnswer = isWaiting;
            MessageTextBox.IsEnabled = !isWaiting;
            SendButton.IsEnabled = !isWaiting;
            StatusTextBlock.Text = isWaiting ? "Ожидание ответа ИИ..." : "Готово";

            if (!isWaiting)
                MessageTextBox.Focus();
        }

        private void ScrollMessagesToEnd()
        {
            if (_session.Messages.Count == 0)
                return;

            MessagesListBox.ScrollIntoView(_session.Messages[_session.Messages.Count - 1]);
        }

        private void SaveSessionSafely()
        {
            try
            {
                _repository.SaveChatSession(_session);
            }
            catch (Exception ex)
            {
                StatusTextBlock.Text = "Ошибка сохранения БД: " + ex.Message;
            }
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            SaveSessionSafely();
            base.OnClosing(e);
        }
    }
}