﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace KPLN_CoordiantorAI.Common
{
    public sealed class StubGigaChatClient : IAiChatClient
    {
        public async Task<string> SendAsync(IEnumerable<ChatMessage> messages, GigaChatSettings settings, CancellationToken cancellationToken)
        {
            await Task.Delay(700, cancellationToken);

            ChatMessage lastUserMessage = messages == null
                ? null
                : messages.LastOrDefault(m => m != null && m.Role == ChatMessageRole.User);

            if (lastUserMessage == null || string.IsNullOrWhiteSpace(lastUserMessage.Text))
                return "Гигачат пока не подключен. Заглушка готова принять следующий шаг интеграции.";

            return "Гигачат пока не подключен. Вопрос сохранен в БД, ответ будет заменен реальным вызовом API на следующем этапе.";
        }
    }
}