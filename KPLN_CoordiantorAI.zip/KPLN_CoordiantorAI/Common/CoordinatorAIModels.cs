﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Text;

namespace KPLN_CoordiantorAI.Common
{
    public enum ChatMessageRole
    {
        User = 0,
        Assistant = 1
    }

    public enum ChatReaction
    {
        Dislike = -1,
        None = 0,
        Like = 1
    }

    public sealed class ChatMessage
    {
        public ChatMessage()
        {
            Id = Guid.NewGuid().ToString("N");
            CreatedAt = DateTime.Now;
        }

        public string Id { get; set; }

        public ChatMessageRole Role { get; set; }

        public string Text { get; set; }

        public DateTime CreatedAt { get; set; }

        public bool IsUserMessage
        {
            get { return Role == ChatMessageRole.User; }
        }

        public string RoleCaption
        {
            get { return IsUserMessage ? "Пользователь" : "ИИ"; }
        }

        public string CreatedAtCaption
        {
            get { return CreatedAt.ToString("HH:mm"); }
        }
    }

    public sealed class ChatSession
    {
        public ChatSession()
        {
            Id = Guid.NewGuid().ToString("N");
            CreatedAt = DateTime.Now;
            UpdatedAt = CreatedAt;
            Reaction = ChatReaction.None;
            Messages = new ObservableCollection<ChatMessage>();
        }

        public string Id { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime UpdatedAt { get; set; }

        public string UserName { get; set; }

        public int SubDepartmentId { get; set; }

        public ChatReaction Reaction { get; set; }

        public ObservableCollection<ChatMessage> Messages { get; private set; }
    }

    public sealed class CurrentUserContext
    {
        public string UserName { get; set; }

        public int SubDepartmentId { get; set; }
    }

    public sealed class GigaChatSettings
    {
        public GigaChatSettings()
        {
            AuthUrl = "https://ngw.devices.sberbank.ru:9443/api/v2/oauth";
            ApiUrl = "https://gigachat.devices.sberbank.ru/api/v1";
            Scope = "GIGACHAT_API_PERS";
            SystemPrompt =
                "Ты ИИ-помощник KPLN CoordinatorAI. Отвечай на русском языке.\r\n" +
                "Стиль общения: сдержанный, спокойный и профессиональный. Пиши по делу, без лишней воды.\r\n" +
                "Иногда можно использовать легкий уместный юмор, но без фамильярности и без шуток в серьезных ситуациях.\r\n" +
                "Если точного ответа нет или данных недостаточно, прямо скажи об этом. Не выдумывай факты, ссылки, нормы, версии программ и чужие решения.\r\n" +
                "Если вопрос неоднозначный, задай короткий уточняющий вопрос или явно перечисли допущения.\r\n" +
                "Когда даешь инструкцию, делай ее пошаговой и проверяемой.";
        }

        public string AuthUrl { get; set; }

        public string ApiUrl { get; set; }

        public string ClientId { get; set; }

        public string ClientSecret { get; set; }

        public string Scope { get; set; }

        public string SystemPrompt { get; set; }
    }

    public static class ChatTranscriptFormatter
    {
        public static string BuildTranscript(IEnumerable<ChatMessage> messages)
        {
            if (messages == null)
                return string.Empty;

            StringBuilder builder = new StringBuilder();
            foreach (ChatMessage message in messages)
            {
                if (message == null)
                    continue;

                builder
                    .Append('[')
                    .Append(message.CreatedAt.ToString("yyyy-MM-dd HH:mm:ss"))
                    .Append("] ")
                    .Append(message.RoleCaption)
                    .Append(": ")
                    .AppendLine(message.Text ?? string.Empty);
            }

            return builder.ToString().TrimEnd();
        }
    }
}